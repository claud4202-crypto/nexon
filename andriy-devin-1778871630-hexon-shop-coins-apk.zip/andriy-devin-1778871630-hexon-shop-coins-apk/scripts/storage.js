/* ---------- Storage ----------
   Two keys are used:
     hexon.deviceId.v1  — the stable player ID. Created once on first
                          launch and NEVER deleted, even when the
                          user signs out or resets progress. This is
                          what guarantees "1 ID per device, forever".
     hexon.beta.v1      — everything else (profile, stats, settings,
                          wallet, shop, etc.).
*/
const STORE_KEY  = "hexon.beta.v1";
const DEVICE_KEY = "hexon.deviceId.v1";

function loadDeviceId(){
  try{
    let id = localStorage.getItem(DEVICE_KEY);
    if(!id || !/^HX-[A-Z0-9]{5}-[A-Z0-9]{5}$/.test(id)){
      id = genId();
      localStorage.setItem(DEVICE_KEY, id);
    }
    return id;
  }catch{
    // No localStorage available — fall back to an in-memory random id
    // so the rest of the game can still run during this session.
    return genId();
  }
}

function loadState(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    if(!raw) return null;
    return JSON.parse(raw);
  }catch{ return null; }
}

function saveState(){
  try{
    const copy = {
      profile: state.profile,
      stats: state.stats,
      settings: state.settings,
      achievements: Array.from(state.achievements),
      hidden: state.hidden,
      dailyTasks: state.dailyTasks,
      leaderboards: state.leaderboards,
      wallet: state.wallet,
      daily: state.daily,
      shop: state.shop,
      run: null, // not persisted across reloads (live game state)
    };
    localStorage.setItem(STORE_KEY, JSON.stringify(copy));
  }catch{}
}

/* Reset progress without touching the device ID — the user keeps
   their permanent player ID even after a full reset. Returns the
   preserved ID so callers can put it back into the fresh profile. */
function resetProgressKeepDeviceId(){
  const keep = loadDeviceId();           // ensures key exists
  try{ localStorage.removeItem(STORE_KEY); }catch{}
  return keep;
}
